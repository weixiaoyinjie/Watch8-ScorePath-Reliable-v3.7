package com.htlive.monitor;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MonitorService extends Service {
    private static final String LIVE_CHANNEL="ht_live_tracking";
    private static final String ALERT_CHANNEL="ht_event_alerts";
    private static final int LIVE_ID=2810;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ExecutorService aiWorker=Executors.newFixedThreadPool(2);
    // Nonessential per-match endpoints run off the single score/alert poll worker.
    private final ExecutorService auxiliaryWorker=Executors.newFixedThreadPool(6);
    private final Semaphore aiSlots=new Semaphore(2);
    private final Object snapshotLock=new Object();
    private static final class AiTask {
        String id,key,riskType;
        JSONObject match;
        ArrayList<Integer> marks;
        long at;
        AiTask(String i,String k,JSONObject m,String r,ArrayList<Integer> marks,long at){
            this.id=i;key=k;match=m;riskType=r;this.marks=new ArrayList<>(marks);this.at=at;
        }
    }
    private SharedPreferences pref;
    private volatile boolean active=false;
    private int interval=120;
    private int notifyId=3000;
    private int apiCalls=0;
    // Auxiliary per-fixture endpoints must not block the main score poll for minutes.
    private static final int MAX_STATS_REQUESTS_PER_CYCLE=4;
    private static final int MAX_EVENT_REQUESTS_PER_CYCLE=2;
    private static final long SECONDARY_BUDGET_MS=9_000L;
    private volatile boolean firstCycle=true;
    private long lastLoggedErrorAt=0L;
    private String lastLoggedError="";

    @Override public void onCreate(){super.onCreate();pref=getSharedPreferences("ht_monitor",MODE_PRIVATE);makeChannels(this);}
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && "STOP".equals(intent.getAction())){stopMonitor();return START_NOT_STICKY;}
        if(!active){
            interval=Math.max(30,Math.min(300,pref.getInt("interval",60)));
            active=true;
            firstCycle=true;
            pref.edit().putBoolean("running",true).apply();
            try {
                Notification n=liveNotification("准备读取已选择的比赛 · 每"+interval+"秒更新");
                if(Build.VERSION.SDK_INT>=34) startForeground(LIVE_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
                else startForeground(LIVE_ID,n);
            } catch(Exception e){
                active=false;pref.edit().putBoolean("running",false).apply();stopSelf();return START_NOT_STICKY;
            }
            tick();
        }
        return START_NOT_STICKY;  // never auto-restart after device kill
    }
    private void tick(){
        if(!active)return;
        worker.execute(()->{
            final long cycleStarted=SystemClock.elapsedRealtime();
            try{ pollOnce(); }
            catch(Exception e){
                pref.edit().putString("lastError",e.getMessage()).apply();
                String issue=String.valueOf(e.getMessage());
                long at=System.currentTimeMillis();
                if(!issue.equals(lastLoggedError) || at-lastLoggedErrorAt>5*60_000L){
                    record("接口异常",issue);lastLoggedError=issue;lastLoggedErrorAt=at;
                }
                String message=issue.length()>125?issue.substring(0,125)+"…":issue;
                updateSnapshotError(message);
                updateOngoingNotification("赛况未更新 · "+message+" · 保留上次有效数据");
            }
            // Honour interval changes without restarting the existing foreground service.
            interval=Math.max(30,Math.min(300,pref.getInt("interval",interval)));
            // Start-to-start refresh: don't add the entire poll duration on top of interval.
            long elapsed=SystemClock.elapsedRealtime()-cycleStarted;
            long delay=Math.max(0L,interval*1000L-elapsed);
            if(active)handler.postDelayed(this::tick,delay);
        });
    }
    private void updateSnapshotError(String error){
        try {
            synchronized(snapshotLock){
                JSONObject snap=new JSONObject(pref.getString("snapshot","{}"));
                // updatedAt is the timestamp of the last SUCCESSFUL batch, not an error ping.
                snap.put("error",error==null?"数据请求异常":error);
                snap.put("errorAt",System.currentTimeMillis());
                snap.put("revisionAt",Math.max(System.currentTimeMillis(),
                    snap.optLong("revisionAt",0L)+1L));
                pref.edit().putString("snapshot",snap.toString()).apply();
                WearMatchSync.send(this,snap,null);
            }
        }catch(Exception ignored){}
    }
    private void pollOnce() throws Exception {
        String csv=pref.getString("watchIds","");
        String key=pref.getString("apiKey","");
        if(csv.isEmpty()||key.isEmpty()){stopMonitor();return;}
        JSONArray fixtures=ApiClient.get("fixtures?ids="+csv.replace(',','-')+"&timezone=America%2FArgentina%2FBuenos_Aires",key).optJSONArray("response");
        apiCalls++;
        if(fixtures==null || fixtures.length()==0)throw new Exception("找不到已选比赛：请核对 API fixture ID / 赛事覆盖");
        final int count=fixtures.length();
        final int cursor=Math.floorMod(pref.getInt("secondaryCursor",0),count);
        final long auxiliaryDeadline=SystemClock.elapsedRealtime()+SECONDARY_BUDGET_MS;
        // Rotate the secondary request priority; don't permanently starve later matches.
        pref.edit().putInt("secondaryCursor",(cursor+2)%count).apply();
        JSONObject previous=new JSONObject(pref.getString("snapshot","{}"));
        JSONObject mainPicks=new JSONObject(pref.getString("mainPicks","{}"));
        JSONObject guardBets=new JSONObject(pref.getString("guardBets","{}"));
        Map<String,JSONObject> old=new HashMap<>();
        JSONArray priorItems=previous.optJSONArray("matches");
        if(priorItems!=null)for(int i=0;i<priorItems.length();i++){
            JSONObject item=priorItems.optJSONObject(i);
            if(item!=null)old.put(item.optString("id"),item);
        }
        // Launch eligible secondary requests in parallel before processing any fixture.
        // A slow low-tier league endpoint can no longer postpone goals for later games.
        Map<String,Future<JSONObject>> statFutures=new HashMap<>();
        Map<String,Future<JSONObject>> eventFutures=new HashMap<>();
        for(int rank=0;rank<count;rank++){
            JSONObject f=fixtures.optJSONObject((cursor+rank)%count);
            if(f==null)continue;
            JSONObject info=f.optJSONObject("fixture");
            if(info==null)continue;
            JSONObject status=info.optJSONObject("status");
            if(status==null || !"1H".equals(status.optString("short")))continue;
            String matchId=String.valueOf(info.optInt("id"));
            JSONObject oldItem=old.get(matchId);
            int minute=status.optInt("elapsed",0);
            JSONObject teams=f.optJSONObject("teams");
            JSONObject homeTeam=teams==null?null:teams.optJSONObject("home");
            JSONObject awayTeam=teams==null?null:teams.optJSONObject("away");
            int homeId=homeTeam==null?0:homeTeam.optInt("id");
            int awayId=awayTeam==null?0:awayTeam.optInt("id");
            boolean embedded=false;
            try{embedded=MatchData.combine(f.optJSONArray("statistics"),homeId,awayId)
                .optBoolean("available",false);}
            catch(Exception e){android.util.Log.w("HT","Embedded stats are not usable",e);}
            long now=System.currentTimeMillis();
            if(!embedded && statFutures.size()<MAX_STATS_REQUESTS_PER_CYCLE &&
               (oldItem==null || now-oldItem.optLong("lastStatsAt",0L)>=60_000L)){
                statFutures.put(matchId,auxiliaryWorker.submit(
                    ()->ApiClient.get("fixtures/statistics?fixture="+matchId+"&half=true",key)));
                apiCalls++;
            }
            boolean dueEvents=oldItem==null ||
                now-oldItem.optLong("lastEventsAt",0L)>=(minute>=40?30_000L:60_000L);
            if(!dueEvents && oldItem!=null){
                JSONObject goals=f.optJSONObject("goals");
                if(goals!=null)dueEvents=oldItem.optInt("h",0)!=goals.optInt("home",0) ||
                    oldItem.optInt("a",0)!=goals.optInt("away",0);
            }
            if(f.optJSONArray("events")==null && dueEvents &&
                eventFutures.size()<MAX_EVENT_REQUESTS_PER_CYCLE){
                eventFutures.put(matchId,auxiliaryWorker.submit(
                    ()->ApiClient.get("fixtures/events?fixture="+matchId,key)));
                apiCalls++;
            }
        }
        JSONArray next=new JSONArray();
        ArrayList<AiTask> pendingAi=new ArrayList<>();
        Set<String> finishedIds=new HashSet<>();
        int activeH=0, finishedH=0, future=0;
        for(int i=0;i<fixtures.length();i++){
            JSONObject f=fixtures.optJSONObject(i);if(f==null)continue;
            JSONObject fInfo=f.optJSONObject("fixture");if(fInfo==null)continue;
            String id=String.valueOf(fInfo.optInt("id"));
            JSONObject oldItem=old.get(id);
            JSONObject statusObj=fInfo.optJSONObject("status");
            String status=statusObj==null?"?":statusObj.optString("short","?");
            int minute=statusObj==null?0:statusObj.optInt("elapsed",0);
            JSONObject teams=f.optJSONObject("teams");
            JSONObject home=teams==null?null:teams.optJSONObject("home");
            JSONObject away=teams==null?null:teams.optJSONObject("away");
            int homeId=home==null?0:home.optInt("id");
            int awayId=away==null?0:away.optInt("id");
            JSONObject goal=f.optJSONObject("goals");
            int h=goal==null||goal.isNull("home")?0:goal.optInt("home");
            int a=goal==null||goal.isNull("away")?0:goal.optInt("away");
            boolean live="1H".equals(status);
            // Never infer halftime from elapsed >=45: 45+ stoppage can continue in 1H.
            boolean ended=MatchLifecycle.shouldPrune(status);
            if(live)activeH++;else if(ended){finishedH++;finishedIds.add(id);}else future++;
            JSONObject now=new JSONObject();
            now.put("id",id).put("home",home==null?"主队":home.optString("name","主队"))
               .put("away",away==null?"客队":away.optString("name","客队"))
               .put("status",status).put("minute",minute).put("h",h).put("a",a)
               .put("fixtureSampledAt",System.currentTimeMillis())
               .put("league",f.optJSONObject("league")==null?"":f.optJSONObject("league").optString("name",""))
               .put("kickoff",fInfo.optString("date",""));
            JSONArray configured=guardBets.optJSONArray(id);
            JSONArray activeBets=configured!=null?configured:new JSONArray();
            String mainPick=mainPicks.optString(id,"");
            if(configured!=null && configured.length()>0){
                JSONObject primary=configured.optJSONObject(0);
                if(primary!=null && ScoreGuardEngine.validPick(primary.optString("pick"))) mainPick=primary.optString("pick");
            } else if(ScoreGuardEngine.validPick(mainPick)){
                activeBets.put(new JSONObject().put("role","主单").put("pick",mainPick).put("closed",false));
            }
            now.put("guardBets",activeBets);
            boolean scoreChanged=oldItem!=null && (h!=oldItem.optInt("h",h) || a!=oldItem.optInt("a",a));
            boolean newGoal=AlertPolicy.goalOccurred(firstCycle,oldItem!=null,live,
                oldItem==null?0:oldItem.optInt("h",0),oldItem==null?0:oldItem.optInt("a",0),h,a);
            if(scoreChanged) now.put("guardLastGoalAt",System.currentTimeMillis());
            else if(oldItem!=null) now.put("guardLastGoalAt",oldItem.optLong("guardLastGoalAt",0L));
            if(MainScoreRiskEngine.validPick(mainPick))now.put("mainPick",mainPick);
            if(oldItem!=null){
                if(oldItem.has("stats")) now.put("stats",oldItem.get("stats"));
                if(oldItem.has("history"))now.put("history",oldItem.get("history"));
                if(oldItem.has("events"))now.put("events",oldItem.get("events"));
                if(oldItem.has("lastPressureNotify"))now.put("lastPressureNotify",oldItem.get("lastPressureNotify"));
                if(oldItem.has("lastGoalNotifyAt"))now.put("lastGoalNotifyAt",oldItem.get("lastGoalNotifyAt"));
                if(oldItem.has("lastGoalNotifyLevel"))now.put("lastGoalNotifyLevel",oldItem.get("lastGoalNotifyLevel"));
                if(oldItem.has("lastGoalNotifySide"))now.put("lastGoalNotifySide",oldItem.get("lastGoalNotifySide"));
                if(oldItem.has("lastGoalNotifyKind"))now.put("lastGoalNotifyKind",oldItem.get("lastGoalNotifyKind"));
                if(oldItem.has("lastRedAt"))now.put("lastRedAt",oldItem.get("lastRedAt"));
                if(oldItem.has("redNotifiedTotal"))now.put("redNotifiedTotal",oldItem.get("redNotifiedTotal"));
                if(oldItem.has("trend"))now.put("trend",oldItem.get("trend"));
                if(oldItem.has("lastStatsAt"))now.put("lastStatsAt",oldItem.get("lastStatsAt"));
                if(oldItem.has("lastStatsSampleAt"))now.put("lastStatsSampleAt",oldItem.get("lastStatsSampleAt"));
                if(oldItem.has("lastStatsChangedAt"))now.put("lastStatsChangedAt",oldItem.get("lastStatsChangedAt"));
                if(oldItem.has("lastDisruptionAt"))now.put("lastDisruptionAt",oldItem.get("lastDisruptionAt"));
                if(oldItem.has("lastEventsAt"))now.put("lastEventsAt",oldItem.get("lastEventsAt"));
                if(oldItem.has("lastDataAlertAt"))now.put("lastDataAlertAt",oldItem.get("lastDataAlertAt"));
                if(oldItem.has("aiReview"))now.put("aiReview",oldItem.get("aiReview"));
                if(oldItem.has("aiReviewAt"))now.put("aiReviewAt",oldItem.get("aiReviewAt"));
                if(oldItem.has("aiReviewCount"))now.put("aiReviewCount",oldItem.get("aiReviewCount"));
                if(oldItem.has("aiReviewMinute"))now.put("aiReviewMinute",oldItem.get("aiReviewMinute"));
                if(oldItem.has("lastMainRiskNotifyAt"))now.put("lastMainRiskNotifyAt",oldItem.get("lastMainRiskNotifyAt"));
                if(oldItem.has("mainPickRisk"))now.put("mainPickRisk",oldItem.get("mainPickRisk"));
                if(oldItem.has("guardRisk"))now.put("guardRisk",oldItem.get("guardRisk"));
                if(oldItem.has("lastGuardAlertAt"))now.put("lastGuardAlertAt",oldItem.get("lastGuardAlertAt"));
            }
            // Changes to target score / manual closure invalidate old advice.
            // Cash-out amounts never enter AI analysis and must not reset pressure evidence.
            boolean selectionChanged=oldItem!=null &&
                (!mainPick.equals(oldItem.optString("mainPick","")) ||
                 !ScoreGuardEngine.selectionSignature(activeBets).equals(
                     ScoreGuardEngine.selectionSignature(oldItem.optJSONArray("guardBets"))));
            if(selectionChanged){
                now.remove("aiReview");now.put("aiReviewAt",0L).put("aiReviewCount",0)
                   .put("aiReviewMinute",-1).put("lastMainRiskNotifyAt",0L);
            }
            // The old half's attack window and AI conclusion cannot survive a goal.
            // This applies even if the next statistics call is throttled or fails.
            if(scoreChanged){
                now.remove("history");now.remove("aiReview");
                now.put("lastStatsSampleAt",0L);
            }
            if(live){
                try{
                    // /fixtures?ids includes live statistics for supported leagues/plans.
                    // Embedded data is preferred: one network round trip for multiple matches.
                    JSONArray embeddedStats=f.optJSONArray("statistics");
                    JSONObject stats=MatchData.combine(embeddedStats,homeId,awayId);
                    boolean embedded=stats.optBoolean("available",false);
                    long fetchAt=System.currentTimeMillis();
                    boolean due=oldItem==null || fetchAt-oldItem.optLong("lastStatsAt",0L)>=60_000L;
                    boolean fetched=embedded;
                    String statsIssue="";
                    Future<JSONObject> statsFuture=statFutures.get(id);
                    if(!embedded && due && statsFuture!=null){
                        try{
                            JSONObject result=awaitAuxiliary(statsFuture,auxiliaryDeadline);
                            stats=MatchData.combine(result.optJSONArray("response"),homeId,awayId);
                            fetched=stats.optBoolean("available",false);
                            if(!fetched)statsIssue="统计接口没有可用数据";
                        }catch(Exception e){statsIssue="统计补查失败或超时："+e.getMessage();}
                    }
                    if(!embedded && !fetched && oldItem!=null && oldItem.has("stats"))
                        stats=oldItem.optJSONObject("stats");
                    boolean statsChanged=oldItem==null || oldItem.optJSONObject("stats")==null ||
                        !stats.toString().equals(oldItem.optJSONObject("stats").toString());
                    if(fetched){
                        now.put("lastStatsAt",fetchAt);
                        if(statsChanged)now.put("lastStatsChangedAt",fetchAt);
                    }
                    now.put("statsSource",embedded?"批量赛况":fetched?"单场统计":"缓存（统计请求轮流调度）");
                    now.put("stats",stats);
                    // Do not emit here: API statistics and /fixtures/events can
                    // report the SAME red card on different polling cycles.
                    // Reconcile both counts once, after both responses are read.
                    boolean scoreReset=oldItem!=null && (h!=oldItem.optInt("h")||a!=oldItem.optInt("a"));
                    // Avoid treating repeated 30-second reads as independent fresh samples.
                    boolean sampleDue=oldItem==null || fetchAt-oldItem.optLong("lastStatsSampleAt",0)>=55_000L;
                    if(stats!=null && stats.optBoolean("available") && fetched && sampleDue){
                        if(scoreReset)now.remove("aiReview");
                        updateTrend(now,scoreReset?null:oldItem,minute);
                        now.put("lastStatsSampleAt",fetchAt);
                    }
                    else if(stats==null || !stats.optBoolean("available"))now.put("trend","无统计覆盖");
                    if(stats==null || !stats.optBoolean("available",false))
                        now.put("dataError","统计未覆盖，不作为实时判断依据");
                    else if(System.currentTimeMillis()-now.optLong("lastStatsAt",0L)>90_000L)
                        now.put("dataError","统计超过90秒未刷新，当前仅展示历史值，风险分析须复核");
                    else now.remove("dataError");
                    if(!statsIssue.isEmpty())now.put("dataError",statsIssue+"；只显示上次有效统计");
                }catch(Exception ex){
                    // A secondary endpoint failure must not erase the last usable sample.
                    if(oldItem!=null && oldItem.optJSONObject("stats")!=null)
                        now.put("stats",oldItem.optJSONObject("stats"));
                    else now.put("stats",new JSONObject().put("available",false));
                    now.put("dataError","统计请求失败（显示旧数据）："+ex.getMessage());
                    now.put("trend","统计未刷新 · 暂停实时判断");
                }
                int eventRedCount=-1;
                try{
                    JSONArray es=f.optJSONArray("events");
                    boolean fetchedEvents=es!=null;
                    long eventTime=System.currentTimeMillis();
                    boolean dueEvents=oldItem==null || eventTime-oldItem.optLong("lastEventsAt",0L)>=(minute>=40?30_000L:60_000L) ||
                         (oldItem.optInt("h",h)!=h || oldItem.optInt("a",a)!=a);
                    Future<JSONObject> eventFuture=eventFutures.get(id);
                    if(es==null && dueEvents && eventFuture!=null){
                        try{
                            JSONObject result=awaitAuxiliary(eventFuture,auxiliaryDeadline);
                            es=result.optJSONArray("response");
                            fetchedEvents=es!=null;
                        }catch(Exception e){now.put("eventError","红牌事件补查失败或超时，保留旧证据："+e.getMessage());}
                    }
                    if(!fetchedEvents){
                        // Event baseline is retained; no false red-card alert on a skipped call.
                        es=null;
                    }
                    JSONArray keys=new JSONArray();
                    Set<String> distinctReds=new HashSet<>();
                    if(es!=null)for(int j=0;j<es.length();j++){
                        JSONObject ev=es.optJSONObject(j);if(ev==null)continue;
                        String type=ev.optString("type");String detail=ev.optString("detail");
                        JSONObject time=ev.optJSONObject("time");
                        int at=time==null?0:time.optInt("elapsed");
                        JSONObject tm=ev.optJSONObject("team");JSONObject player=ev.optJSONObject("player");
                        String eventKey=type+":"+detail+":"+at+":"+(time==null?0:time.optInt("extra",0))+":"+(tm==null?0:tm.optInt("id"))+":"+(player==null?0:player.optInt("id"));
                        keys.put(eventKey);
                        if(isRedEvent(type,detail)){
                            // An API may describe one sending-off as both second
                            // yellow and red: dedupe by player/team/clock.
                            int teamId=tm==null?0:tm.optInt("id");
                            int playerId=player==null?0:player.optInt("id");
                            distinctReds.add(AlertPolicy.redEventIdentity(teamId,playerId,at,
                                time==null?0:time.optInt("extra",0),j));
                        }
                    }
                    if(fetchedEvents){
                        now.put("events",keys);now.put("lastEventsAt",eventTime);
                        eventRedCount=distinctReds.size();
                    }
                }catch(Exception ex){now.put("eventError","红牌事件暂不可用："+ex.getMessage());}
                // Compare one reconciled red-card total, AFTER both sources were
                // checked. If event data is unavailable, statistics alone still
                // triggers the alert; delayed events won't notify a second time.
                try{
                    int fromStats=countStatReds(now.optJSONObject("stats"));
                    int observed=AlertPolicy.combinedRedCount(fromStats,eventRedCount);
                    int oldBaseline=oldItem==null?0:oldItem.has("redNotifiedTotal")?
                        oldItem.optInt("redNotifiedTotal",0):
                        Math.max(0,countStatReds(oldItem.optJSONObject("stats")));
                    if(!firstCycle && oldItem!=null && !oldItem.has("redNotifiedTotal")){
                        oldBaseline=Math.max(oldBaseline,countOldRedEvents(oldItem));
                    }
                    if(AlertPolicy.newRedCard(firstCycle,oldItem!=null,oldBaseline,observed)){
                        int increased=observed-oldBaseline;
                        long alertAt=System.currentTimeMillis();
                        now.put("newRed",true).put("lastRedAt",alertAt)
                           .put("lastDisruptionAt",alertAt);
                        now.remove("aiReview");
                        AlertNotifier.post(this,"🟥 红牌 · 比赛人数变化",id,now,alertAt,
                            "全场已确认红牌数量增加"+increased+"张（统计/事件交叉去重），请核对球队和球员");
                        GuardJournal.append(this,id,"红牌/人数变化",now,alertAt);
                    }
                    now.put("redNotifiedTotal",Math.max(oldBaseline,Math.max(0,observed)));
                    if(now.optBoolean("newRed",false)){
                        JSONArray fresh=new JSONArray();
                        fresh.put(new JSONObject().put("time",System.currentTimeMillis())
                            .put("minute",minute).put("stats",now.optJSONObject("stats")));
                        now.put("history",fresh);
                    }
                }catch(Exception ex){now.put("eventError","红牌合并校验失败："+ex.getMessage());}
                // The warning engine uses both ~5min and ~10min *observed* deltas.
                // The older single-threshold pressure notification is not emitted
                // as a second alert, avoiding duplicate/conflicting warnings.
                try {
                    long when=System.currentTimeMillis();
                    JSONObject warning=GoalWarningEngine.analyze(now,oldItem,when);
                    now.put("goalWarning",warning);
                    GoalWarningEngine.attachWindows(now,when);

                } catch(Exception e) {
                    now.put("goalWarning",new JSONObject().put("level","PASS").put("rating","PASS")
                        .put("title","预警运算失败").put("reason",e.getMessage()));
                }
                // A single user-provided exact score is evaluated independently of the
                // generic symmetric goal-warning engine. Missing odds never become estimates.
                try{
                    if(MainScoreRiskEngine.validPick(mainPick))
                        now.put("mainPickRisk",MainScoreRiskEngine.analyze(now,oldItem,mainPick,System.currentTimeMillis()));
                    else now.remove("mainPickRisk");
                }catch(Exception ex){now.put("mainPickRiskError",ex.getMessage());}
                // Score-first guard: goals are facts, pressure signals need fresh 3/5/10m data.
                // All unmatched positions are tracked; both teams can break a HIT score.
                String riskType=null;
                java.util.ArrayList<Integer> marksSent=new java.util.ArrayList<>();
                try {
                    long evaluatedAt=System.currentTimeMillis();
                    JSONObject fast=guardFastWindow(now,oldItem);
                    if(fast!=null)now.put("guardFast",fast);
                    JSONObject g=ScoreGuardEngine.analyze(now,activeBets,evaluatedAt);
                    now.put("guardRisk",g);
                    JSONObject prior=oldItem==null?null:oldItem.optJSONObject("guardRisk");
                    String level=g.optString("level"),before=prior==null?"":prior.optString("level");
                    long prevSent=oldItem==null?0:oldItem.optLong("lastGuardAlertAt",0L);
                    boolean holdingRisk="HIGH".equals(level)||"WATCH".equals(level);
                    boolean isUpgrade="HIGH".equals(level)&&!"HIGH".equals(before);
                    boolean newlyHit=g.optInt("hit")>0&&(prior==null||prior.optInt("hit")<=0);
                    boolean allBroken="BROKEN".equals(level)&&!"BROKEN".equals(before);
                    boolean reachMomentum="REACH_WATCH".equals(level) && !"REACH_WATCH".equals(before);
                    boolean scoreCorrection=scoreChanged && !newGoal;
                    boolean shouldAlert=!newGoal && !now.optBoolean("newRed",false) && (allBroken ||
                        reachMomentum ||
                        (selectionChanged && (g.optInt("hit")>0 || holdingRisk)) ||
                        (newlyHit && minute>=3) ||
                        (holdingRisk && (!holdingRiskLevel(before)||isUpgrade)) ||
                        (holdingRisk && prevSent>0 && evaluatedAt-prevSent>=5*60_000L &&
                            !GuardActionReceiver.isAcknowledged(this,id) && hasFreshNewAttack(now,oldItem)));
                    if(shouldAlert){
                        String type=allBroken?"⛔ 全部比分单失效":reachMomentum?"📈 所需进球方出现攻势":newlyHit?"🎯 比分命中 · 开始守分":"🛡 守分风险 · 核查结算";
                        AlertNotifier.post(this,type,id,now,evaluatedAt,g.optString("reason"));
                        GuardJournal.append(this,id,type,now,evaluatedAt);
                        now.put("lastGuardAlertAt",evaluatedAt);
                        if(holdingRisk)GuardActionReceiver.arm(this,id,type,now,evaluatedAt);
                        if(holdingRisk || reachMomentum || (selectionChanged && g.optInt("hit")>0))riskType=type;
                    }
                    if(!holdingRisk)GuardActionReceiver.disarm(this,id);
                    else GuardActionReceiver.repeatIfUnacknowledged(this,id,now,evaluatedAt);
                    if(scoreCorrection){
                        riskType="🔄 比分更正 / VAR · 重新核对";
                        AlertNotifier.post(this,riskType,id,now,evaluatedAt,
                            "数据源比分回退或更正，已重置旧判断；需复核主单/保险单状态");
                        GuardJournal.append(this,id,"比分更正/VAR后重新核对",now,evaluatedAt);
                        GuardActionReceiver.disarm(this,id);
                    }
                    if(newGoal){
                        riskType="⚽ 进球 · 比分路径核对";
                        AlertNotifier.post(this,riskType,id,now,evaluatedAt,
                            "逐张核对命中/待达/失效和主客双方的下一球承接路径；守分必须重新采集进球后证据");
                        GuardJournal.append(this,id,"进球后比分状态核对",now,evaluatedAt);
                        GuardActionReceiver.disarm(this,id); // fresh score makes earlier warnings obsolete
                    }
                }catch(Exception e){now.put("guardRiskError",e.toString());}
                // Independent fixed data-review checkpoints retained from the original app.
                // Match kickoff, 15', 30' and 40' are informational, NOT exit orders.
                // Dedupe across service polling and Android scheduled receiver.
                try{
                    long checkpointAt=System.currentTimeMillis();
                    if(AlertNotifier.postKickoff(this,id,now,checkpointAt))marksSent.add(0);
                    int prevMinute=oldItem==null?-1:oldItem.optInt("minute",-1);
                    for(int mark:AlertPolicy.MARKS){
                        if(AlertPolicy.checkpointDue(prevMinute,minute,mark) &&
                           AlertNotifier.postMark(this,id,mark,now,checkpointAt))marksSent.add(mark);
                    }
                }catch(Exception e){now.put("checkpointError",e.getMessage());}
                // Keep AI network latency OFF the single live polling thread:
                // data-backed alerts already fired above and AI revises the same banner.
                try{
                    String aiKey=pref.getString("openaiKey","").trim();
                    if(aiKey.isEmpty())now.remove("aiReview");
                    long aiNow=System.currentTimeMillis();
                    int aiCount=now.optInt("aiReviewCount",0);
                    boolean relevant=!marksSent.isEmpty() || riskType!=null || now.optBoolean("newRed",false);
                    if(!aiKey.isEmpty() && relevant && aiCount<14 &&
                       now.optLong("lastStatsAt",0L)>0 &&
                       aiNow-now.optLong("lastStatsAt",0L)<=85_000L && aiSlots.tryAcquire()){
                        now.put("aiReviewAt",aiNow).put("aiReviewMinute",minute).put("aiReviewCount",aiCount+1);
                        pendingAi.add(new AiTask(id,aiKey,new JSONObject(now.toString()),riskType,marksSent,aiNow));
                        now.put("aiReviewError","AI复核已排队；风险通知不等待AI");
                    }
                }catch(Exception aiError){now.put("aiReviewError",aiError.getMessage());}
            } else {
                now.put("goalWarning",new JSONObject().put("level","PASS").put("rating","PASS").put("title","非上半场，暂停预警"));
                if(ended)now.put("trend","上半场已结束");
                if(!ended)now.put("trend","等待开赛");
            }
            // Do not keep HT/2H/FT fixtures in analysis or watchlist.
            // No halftime notification is emitted for a finished fixture.
            if(ended && (oldItem==null || !MatchLifecycle.shouldPrune(oldItem.optString("status"))))
                GuardJournal.append(this,id,"半场完成 · 记录最终比分",now,System.currentTimeMillis());
            if(!ended)next.put(now);
        }
        String remainingCsv=csv;
        if(!finishedIds.isEmpty()){
            JSONArray gone;
            try{gone=new JSONArray(pref.getString("autoPruned","[]"));}catch(Exception ex){gone=new JSONArray();}
            Set<String> prior=new HashSet<>();for(int q=0;q<gone.length();q++)prior.add(gone.optString(q));
            StringBuilder kept=new StringBuilder();
            for(String selected:csv.split(",")){
                if(finishedIds.contains(selected)){
                    if(prior.add(selected))gone.put(selected);
                }else if(!selected.isEmpty()){
                    if(kept.length()>0)kept.append(',');kept.append(selected);
                }
            }
            remainingCsv=kept.toString();
            // Avoid overwriting a concurrent user edit of the watchlist.
            if(csv.equals(pref.getString("watchIds",""))){
                pref.edit().putString("watchIds",remainingCsv).putString("autoPruned",gone.toString()).apply();
            }
            // Pending alarms are cancelled even if the watchlist changed while polling.
            ReminderReceiver.cancelFinished(this,finishedIds);
            // The user requested automatic deletion of *this fixture's* monitoring
            // history on true HT, with no collateral deletion of unrelated matches.
            AlertNotifier.purgeFinished(this,finishedIds);
        }
        // Do not let an unresponsive API remain in charge of when the next score poll runs.
        for(Future<JSONObject> f:statFutures.values())if(!f.isDone())f.cancel(true);
        for(Future<JSONObject> f:eventFutures.values())if(!f.isDone())f.cancel(true);
        JSONObject state=new JSONObject();
        state.put("updatedAt",System.currentTimeMillis()).put("matches",next)
             .put("revisionAt",System.currentTimeMillis())
             .put("interval",interval).put("apiCallsSession",apiCalls).put("error","");
        synchronized(snapshotLock){
            JSONObject previousSaved=new JSONObject(pref.getString("snapshot","{}"));
            state.put("revisionAt",Math.max(System.currentTimeMillis(),
                previousSaved.optLong("revisionAt",0L)+1L));
            pref.edit().putString("snapshot",state.toString()).putString("lastError","").apply();
        }
        WearMatchSync.send(this,state,null);
        for(AiTask task:pendingAi){
            try{aiWorker.execute(()->completeAiTask(task));}
            catch(java.util.concurrent.RejectedExecutionException e){aiSlots.release();}
        }
        firstCycle=false;
        updateOngoingNotification(activeH+"场上半场进行中 · "+future+"场等待 · "+finishedH+"场已结束");
        // Stop when no fixtures remain; no automatic halftime push is sent.
        if(remainingCsv.isEmpty()){
            handler.post(()->{if(pref.getString("watchIds","").isEmpty())stopMonitor();});
        }
    }

    /** All secondary calls share one hard wall-clock budget, not one timeout per fixture. */
    private static JSONObject awaitAuxiliary(Future<JSONObject> future,long deadline) throws Exception {
        long left=deadline-SystemClock.elapsedRealtime();
        if(left<=0L)throw new TimeoutException("补查超过9秒预算");
        try{return future.get(left,TimeUnit.MILLISECONDS);}
        catch(java.util.concurrent.ExecutionException ex){
            Throwable cause=ex.getCause();
            throw new Exception(cause==null?"补查失败":String.valueOf(cause.getMessage()),cause);
        }
    }

    private void completeAiTask(AiTask task){
        JSONObject review=null;String problem="";
        try{review=AiReview.review(task.match,task.key);}
        catch(Exception e){problem="AI暂不可用："+e.getMessage();}
        try{
            JSONObject updated=null;
            JSONObject watchRefresh=null;
            synchronized(snapshotLock){
                JSONObject snapshot=new JSONObject(pref.getString("snapshot","{}"));
                JSONArray matches=snapshot.optJSONArray("matches");
                if(matches!=null)for(int i=0;i<matches.length();i++){
                    JSONObject current=matches.optJSONObject(i);
                    if(current==null || !task.id.equals(current.optString("id")))continue;
                    if(!pref.getBoolean("running",false) || !"1H".equals(current.optString("status")) ||
                        current.optInt("h",-1)!=task.match.optInt("h",-2) ||
                        current.optInt("a",-1)!=task.match.optInt("a",-2) ||
                        !current.optString("mainPick","").equals(task.match.optString("mainPick","")) ||
                        !String.valueOf(current.optJSONArray("guardBets")).equals(String.valueOf(task.match.optJSONArray("guardBets"))) ||
                        System.currentTimeMillis()-task.at>180_000L ||
                        current.optLong("lastStatsAt",0L)>task.match.optLong("lastStatsAt",0L)+90_000L)break;
                    if(review!=null){current.put("aiReview",review);current.remove("aiReviewError");}
                    else current.put("aiReviewError",problem);
                    snapshot.put("revisionAt",Math.max(System.currentTimeMillis(),
                        snapshot.optLong("revisionAt",0L)+1L));
                    pref.edit().putString("snapshot",snapshot.toString()).apply();
                    watchRefresh=new JSONObject(snapshot.toString());
                    if(review!=null)updated=new JSONObject(current.toString());
                    break;
                }
            }
            // This is a data refresh, not a new independent push/buzz.
            if(watchRefresh!=null)WearMatchSync.send(this,watchRefresh,null);
            if(updated!=null){
                // Update the in-app checkpoint/AI detail, not the Android banner.
                // A later AI reply must NEVER create an extra push or buzz for
                // an already-delivered goal or guard-risk notification.
                if(task.riskType!=null){
                    // Same notification ID, AI may clarify but never independently create a bet order.
                    AlertNotifier.update(this,task.riskType,task.id,updated,System.currentTimeMillis());
                }
            }
        }catch(Exception e){android.util.Log.w("HT","AI result merge failed",e);}
        finally{aiSlots.release();}
    }

    /** Fast 1–2 minute *observed* growth between two same-score API statistics samples.
     * Never subtract a pre-goal baseline from a post-goal cumulative total. */
    private static JSONObject guardFastWindow(JSONObject now,JSONObject old)throws Exception{
        if(old==null || now.optInt("h",-1)!=old.optInt("h",-2) ||
            now.optInt("a",-1)!=old.optInt("a",-2))return null;
        long prevAt=old.optLong("lastStatsAt",0L),nextAt=now.optLong("lastStatsAt",0L);
        long lastGoal=now.optLong("guardLastGoalAt",0L);
        if(prevAt<=0||nextAt-prevAt<55_000L||nextAt-prevAt>180_000L||
            (lastGoal>0 && prevAt<lastGoal))return null;
        JSONObject p=old.optJSONObject("stats"),n=now.optJSONObject("stats");
        if(p==null||n==null||!p.optBoolean("available")||!n.optBoolean("available"))return null;
        JSONObject out=new JSONObject().put("minutes",Math.max(1,Math.round((nextAt-prevAt)/60_000f)));
        for(String side:new String[]{"home","away"}){
            JSONObject a=n.optJSONObject(side),b=p.optJSONObject(side);
            if(a==null||b==null)return null;
            JSONObject change=new JSONObject();
            for(String f:new String[]{"shots","on","box","xg"}){
                if(a.isNull(f)||b.isNull(f)){
                    if(!"xg".equals(f))return null;
                    change.put(f,JSONObject.NULL);continue;
                }
                double x=a.optDouble(f,-1),y=b.optDouble(f,-1);
                if(x<0||y<0||x<y)return null;
                change.put(f,Math.round((x-y)*100.0)/100.0);
            }
            out.put(side,change);
        }
        return out;
    }
    private static boolean holdingRiskLevel(String level){
        return "HIGH".equals(level)||"WATCH".equals(level);
    }
    private static boolean hasFreshNewAttack(JSONObject now,JSONObject old){
        JSONObject current=now.optJSONObject("stats"),last=old==null?null:old.optJSONObject("stats");
        if(current==null||last==null)return false;
        for(String side:new String[]{"home","away"}){
            JSONObject a=current.optJSONObject(side),b=last.optJSONObject(side);
            if(a==null||b==null)continue;
            for(String field:new String[]{"on","box","shots"})
                if(!a.isNull(field)&&!b.isNull(field) && a.optInt(field,0)>b.optInt(field,0))return true;
            if(!a.isNull("xg")&&!b.isNull("xg")&&a.optDouble("xg",0)>b.optDouble("xg",0)+.02)return true;
        }
        return false;
    }
    private static int valueOr(JSONObject side,String key){
        return side==null || side.isNull(key)?-1:side.optInt(key,-1);
    }
    private static boolean isRedEvent(String type,String detail){
        if(!"Card".equalsIgnoreCase(type) || detail==null)return false;
        String d=detail.toLowerCase(java.util.Locale.ROOT);
        return d.contains("red") || d.contains("second yellow");
    }
    private static int countStatReds(JSONObject stats){
        if(stats==null)return -1;
        JSONObject home=stats.optJSONObject("home"),away=stats.optJSONObject("away");
        boolean h=home!=null && home.has("red") && !home.isNull("red");
        boolean a=away!=null && away.has("red") && !away.isNull("red");
        if(!h && !a)return -1;
        return Math.max(0,h?home.optInt("red",0):0)+Math.max(0,a?away.optInt("red",0):0);
    }
    private static int countOldRedEvents(JSONObject old){
        if(old==null)return 0;
        JSONArray events=old.optJSONArray("events");
        if(events==null)return 0;
        Set<String> cards=new HashSet<>();
        for(int i=0;i<events.length();i++){
            String s=events.optString(i,"");
            if(!s.startsWith("Card:") || !isRedEvent("Card",s))continue;
            // Legacy keys use type:detail:minute:extra:team:player.
            // Reconcile duplicated second-yellow and red descriptions even
            // if a provider later adjusts the event's recorded minute.
            try{
                String[] parts=s.split(":");
                if(parts.length<6)throw new IllegalArgumentException("short key");
                int n=parts.length;
                int at=Integer.parseInt(parts[n-4]);
                int extra=Integer.parseInt(parts[n-3]);
                int team=Integer.parseInt(parts[n-2]);
                int player=Integer.parseInt(parts[n-1]);
                cards.add(AlertPolicy.redEventIdentity(team,player,at,extra,i));
            }catch(Exception ex){cards.add(s);}
        }
        return cards.size();
    }
    private void updateTrend(JSONObject now,JSONObject old,int minute)throws Exception{
        JSONObject stats=now.optJSONObject("stats");
        if(stats==null || !stats.optBoolean("available")){now.put("trend","统计缺失");return;}
        JSONArray history=old==null?null:old.optJSONArray("history");
        if(history==null)history=new JSONArray();
        JSONArray retained=new JSONArray();
        long nowTime=System.currentTimeMillis();
        for(int i=0;i<history.length();i++){
            JSONObject point=history.optJSONObject(i);
            if(point!=null && point.optLong("time")>=nowTime-12*60_000L && point.optInt("minute")<=minute)retained.put(point);
        }
        JSONObject sample=new JSONObject().put("time",nowTime).put("minute",minute).put("stats",stats);
        retained.put(sample);
        while(retained.length()>40){JSONArray reduced=new JSONArray();for(int i=1;i<retained.length();i++)reduced.put(retained.get(i));retained=reduced;}
        now.put("history",retained);
        JSONObject oldSample=null;
        for(int i=retained.length()-2;i>=0;i--){
            JSONObject p=retained.optJSONObject(i);
            if(p!=null && nowTime-p.optLong("time")>=4*60_000L && minute-p.optInt("minute")>=3){oldSample=p;break;}
        }
        if(oldSample==null){now.put("trend","积累5分钟样本中");now.remove("delta");return;}
        JSONObject past=oldSample.optJSONObject("stats");
        if(past==null){now.put("trend","等待统计");return;}
        double[] p=new double[2];
        JSONObject deltas=new JSONObject();
        String[] labels={"home","away"};
        for(int i=0;i<2;i++){
            JSONObject cur=stats.optJSONObject(labels[i]); JSONObject prev=past.optJSONObject(labels[i]);
            int on=valueOr(cur,"on"),box=valueOr(cur,"box"),shots=valueOr(cur,"shots");
            int prevOn=valueOr(prev,"on"),prevBox=valueOr(prev,"box"),prevShots=valueOr(prev,"shots");
            if(on<0||box<0||shots<0||prevOn<0||prevBox<0||prevShots<0){now.put("trend","射门统计不完整");return;}
            JSONObject d=new JSONObject();
            d.put("shots",Math.max(0,shots-prevShots));d.put("on",Math.max(0,on-prevOn));d.put("box",Math.max(0,box-prevBox));
            deltas.put(labels[i],d);
            p[i]=Math.max(0,on-prevOn)*1.1+Math.max(0,box-prevBox)*0.9+Math.max(0,shots-prevShots)*0.25;
        }
        String trend="攻守胶着";
        if(p[0]>=3 && p[0]>=p[1]+1.8)trend="主队近5分钟压制";
        else if(p[1]>=3 && p[1]>=p[0]+1.8)trend="客队近5分钟压制";
        else if(p[0]<0.8&&p[1]<0.8)trend="近5分钟机会较少";
        now.put("delta",deltas).put("trend",trend).put("pressureHome",Math.round(p[0]*10)/10.0).put("pressureAway",Math.round(p[1]*10)/10.0);
        now.put("trendWindowMinute",minute-oldSample.optInt("minute"));
    }
    private void record(String title,String detail){
        try{
            JSONArray previous=new JSONArray(pref.getString("alerts","[]"));
            JSONArray updated=new JSONArray();
            updated.put(new JSONObject().put("time",System.currentTimeMillis()).put("title",title).put("detail",detail));
            for(int i=0;i<Math.min(79,previous.length());i++)updated.put(previous.get(i));
            pref.edit().putString("alerts",updated.toString()).apply();
        }catch(Exception ignored){}
    }
    private void alert(String title,String msg){
        record(title,msg);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ALERT_CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle(title.length()>26?title.substring(0,25)+"…":title)
         .setContentText(msg.length()>42?msg.substring(0,41)+"…":msg)
         .setAutoCancel(true).setLocalOnly(false).setContentIntent(openAppIntent()).setWhen(System.currentTimeMillis());
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(++notifyId,b.build());
    }
    private PendingIntent openAppIntent(){
        Intent i=new Intent(this,MainActivity.class);i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification liveNotification(String content){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,LIVE_CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("HT 上半场监控正在运行")
                .setContentText(content).setOngoing(true).setContentIntent(openAppIntent()).build();
    }
    private void updateOngoingNotification(String text){
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(LIVE_ID,liveNotification(text));
    }
    private static void makeChannels(Context ctx){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=(NotificationManager)ctx.getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel run=new NotificationChannel(LIVE_CHANNEL,"运行状态",NotificationManager.IMPORTANCE_LOW);
            run.setDescription("前台实时比赛监控状态");nm.createNotificationChannel(run);
            NotificationChannel urgent=new NotificationChannel(ALERT_CHANNEL,"监控通知测试",NotificationManager.IMPORTANCE_HIGH);
            urgent.setDescription("应用权限测试和基础提醒；守分通知使用独立渠道");
            urgent.enableVibration(true);nm.createNotificationChannel(urgent);
        }
    }
    public static void testAlert(Context ctx){
        makeChannels(ctx);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(ctx,ALERT_CHANNEL):new Notification.Builder(ctx);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("🔔 Watch8 测试")
         .setContentText("若手表收到这条通知，说明手机通知桥接已开启。")
         .setStyle(new Notification.BigTextStyle().bigText("Watch8 通知连接测试\n手机→手表自动同步\n若未收到请检查 Galaxy Wearable 设置"))
         .setLocalOnly(false).setAutoCancel(true);
        ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(2985,b.build());
    }
    private void stopMonitor(){
        active=false;
        handler.removeCallbacksAndMessages(null);
        pref.edit().putBoolean("running",false).apply();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }
    @Override public void onDestroy(){
        active=false;handler.removeCallbacksAndMessages(null);
        worker.shutdownNow();aiWorker.shutdownNow();auxiliaryWorker.shutdownNow();pref.edit().putBoolean("running",false).apply();
        super.onDestroy();
    }
    @Override public void onTimeout(int startId,int fgsType){
        if(Build.VERSION.SDK_INT>=35){record("后台监控到时","Android后台服务达到运行时限，请打开App重新启动。");stopMonitor();}
    }
}
