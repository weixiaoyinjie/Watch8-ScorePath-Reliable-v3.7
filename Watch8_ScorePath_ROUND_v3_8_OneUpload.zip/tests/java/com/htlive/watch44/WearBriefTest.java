package com.htlive.watch44;
import org.json.JSONArray;
import org.json.JSONObject;
public class WearBriefTest {
    private static void ok(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        long now=1_780_000_000_000L;
        JSONObject j=new JSONObject().put("kind","🛡 守分预警")
            .put("teams","主队 vs 客队").put("score","1-0").put("minute",32)
            .put("sourceAt",now-25000).put("statsFresh",true).put("level","HIGH")
            .put("riskTitle","主单已命中，下一球风险上升")
            .put("riskAction","核查平台实时结算报价")
            .put("bets",new JSONArray()
                .put(new JSONObject().put("role","主单").put("pick","1-0").put("state","HIT"))
                .put(new JSONObject().put("role","保险1").put("pick","2-0").put("state","PENDING"))
                .put(new JSONObject().put("role","保险2").put("pick","1-1").put("state","BROKEN")));
        WearBrief brief=WearBrief.from(j,now);
        ok(brief.picks.length==3,"all three tickets must survive");
        ok(brief.picks[0].label.equals("主1-0") && brief.picks[0].state.equals("命中中"),"main status");
        ok(brief.picks[1].label.equals("保2-0") && brief.picks[1].state.equals("待达"),"first insurance");
        ok(brief.picks[2].label.equals("保1-1") && brief.picks[2].state.equals("失效"),"second insurance");
        ok(brief.nativePreview().contains("主1-0"),"system card must show placed score");
        ok(brief.nativeExpanded().contains("核查平台实时结算报价"),"preserve phone action");
        ok(brief.dataLabel.contains("已采集") && brief.ageLabel.contains("25秒"),"freshness");
        JSONObject missing=new JSONObject().put("score","?-?").put("line3","查看手机")
            .put("sourceAt",now-180000L).put("statsFresh",false);
        WearBrief old=WearBrief.from(missing,now);
        ok(old.picks.length==0 && old.nativePreview().contains("未同步"),"missing selections cannot be invented");
        ok(old.ageLabel.contains("滞后") && old.dataLabel.contains("缺失"),"stale data signaled");
        System.out.println("PASS: round-face brief, three exact score selections, missing stats, legacy compatibility");
    }
}
